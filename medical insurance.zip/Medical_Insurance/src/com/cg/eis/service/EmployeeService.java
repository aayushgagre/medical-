package com.cg.eis.service;

import java.util.Map;

import com.cg.eis.bean.Employee;

public interface EmployeeService {

	public boolean addEmployeeDetails(Employee e);
	public String insuranceScheme(Employee e,long salary, String designation);
	public Employee getEmployeeDetails(int id);
	
	
}
