package com.cg.eis.service;

import com.cg.eis.bean.Employee;

public class Service {
	
	EmployeeService emp=new EmployeeServiceImpl();
	
	public boolean insurance(int id, String name, double salary)
	{
		String designation = "";
		String Insurance = "";
		if(salary>5000 && salary<20000)
		{
			designation = "System Associate";
			Insurance = "Scheme C";
		}
		if(salary>=20000 && salary<40000)
		{
			designation = "Programmar";
			Insurance = "Scheme B";
		}
		if(salary>=40000)
		{
			designation = "Manager";
			Insurance = "Scheme A";
		}
		if(salary<5000)
		{
			designation = "Clerk";
			Insurance = "No Scheme";
		}
		
		Employee e=new Employee(id,name,salary,designation,Insurance);
		
		
		return emp.addEmployeeDetails(e);
	}

	public Employee getEmployeeDetails(int id) {
		return emp.getEmployeeDetails(id);
	}

	public void printStatement(Employee e)
	{
		System.out.println("==========================");
		System.out.println("Employee ID: " + e.getId());

		System.out.println("Employee Name: " + e.getName());
		System.out.println("Employee Salary: " + e.getSalary());

		System.out.println("Employee Designation: " + e.getDesignation());

		System.out.println("Employee Salary: " + e.getInsu_schm());
		System.out.println("==========================");
	}

}
