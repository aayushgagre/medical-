package com.cg.eis.pl;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import com.cg.eis.bean.Employee;
import com.cg.eis.service.Service;

public class MyMain {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		Service sc=new Service();
		
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		
		String choice="";
		while(true)
		{
			System.out.println("Welcome");
			System.out.println("=========");
			System.out.println("1. Add the employee details");
			System.out.println("2. Dislay the details of employee.");
			
			choice=br.readLine();
			
			switch(choice)
			{
			case"1" : //add the details
				System.out.println("Enter the employee ID");
				String s_id=br.readLine();
				int id=Integer.parseInt(s_id);
				
				System.out.println("Enter the employee name");
				String name=br.readLine();
				
				System.out.println("Enter the employee salary");
				String s_salary=br.readLine();
				double salary=Double.parseDouble(s_salary);
				
				boolean b=sc.insurance(id,name,salary);
				System.out.println(b);
				
			case "2" : //display the details
				
				System.out.println(" Enter the ID of employee ");
				String s_id1=br.readLine();
				int id1=Integer.parseInt(s_id1);
				
				Employee b1=sc.getEmployeeDetails(id1);
				sc.printStatement(b1);
				
				
			default : System.out.println("Invalid choice");
			}

		}
		

	}

}
