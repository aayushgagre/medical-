package com.cg.DAO;

import com.cg.eis.bean.Employee;

public interface EmployeeDAO {
	

		public boolean addEmployeeDetails(Employee e);
		
		public Employee getEmployeeDetails(int id);
		
		
		

}
