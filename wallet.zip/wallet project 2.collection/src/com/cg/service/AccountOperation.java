package com.cg.service;
import java.util.Map;

import com.cg.bean.*;
public interface AccountOperation {
	
	public boolean addAccount(Account ob);
	public boolean deleteAccount(Account ob);
	public boolean findAccount(Long mobileno);
	public Map<Long,Account> getAllAccounts();

}
